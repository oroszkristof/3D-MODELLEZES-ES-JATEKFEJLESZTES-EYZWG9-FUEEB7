
package tradedesk;

public class Main {

    public static void main(String[] args) {

        Window window = new Window();

        try {

            window.init();

            Game game = new Game();
            game.start();

            window.setGame(game);

            Input input = new Input(window, game);
            input.init();

            while (!window.shouldClose()) {
                window.update();
                input.update();
                window.render();
            }

        } finally {
            window.cleanup();
        }
    }
}