package tradedesk;

public class Game {

    private final Client[] clients;

    private int current_client = 0;
    private boolean game_finished = false;

    private String last_investment = "";
    private String last_result = "";
    private int correct_decisions = 0;

    public Game() {

        clients = new Client[]{
                new Client(
                        "Kovacs Peter",
                        1000000,
                        "Biztonsagos megtakaritas"
                ),
                new Client(
                        "Nagy Anna",
                        3000000,
                        "Hosszu tavu novekedes"
                ),
                new Client(
                        "Szabo Laszlo",
                        500000,
                        "Rovid tavu befektetes"
                )
        };

        clients[0].setRiskProfile(
                "Alacsony",
                5.0,
                "Ovatos"
        );

        clients[1].setRiskProfile(
                "Magas",
                12.0,
                "Kockazatvallalo"
        );

        clients[2].setRiskProfile(
                "Kozepes",
                8.0,
                "Kiegyensulyozott"
        );
    }

    public void start() {
        System.out.println("=== TradeDesk 2D ===");
        showCurrentClient();
    }

    private void showCurrentClient() {

        System.out.println();
        System.out.println("Uj ugyfel erkezett!");
        System.out.println(
                "Ugyfel: " + (current_client + 1)
                        + "/" + clients.length
        );

        clients[current_client].showInfo();

        System.out.println("Valassz befektetest:");
        System.out.println("1 - Allampapir");
        System.out.println("2 - Reszveny");
        System.out.println("3 - Befektetesi alap");
    }

    public void chooseInvestment(int choice) {

        if (game_finished) {
            System.out.println("Minden ugyfel kiszolgalva!");
            return;
        }

        String investment;

        switch (choice) {
            case 1:
                investment = "Állampapír";
                break;
            case 2:
                investment = "Részvény";
                break;
            case 3:
                investment = "Befektetési alap";
                break;
            default:
                System.out.println("Ervenytelen valasztas!");
                return;
        }

        Client client = clients[current_client];

        boolean suitable =
                (client.getRiskLevel().equals("Alacsony") && choice == 1)
                        || (client.getRiskLevel().equals("Magas") && choice == 2)
                        || (client.getRiskLevel().equals("Kozepes") && choice == 3);

        last_investment = investment;

        if (suitable) {
            correct_decisions++;
            last_result = "Megfelelő befektetés!";
            System.out.println(
                    "A befektetes megfelel az ugyfel profiljanak!"
            );
        } else {
            last_result = "Nem megfelelő befektetés!";
            System.out.println(
                    "A befektetes nem megfelelo az ugyfel profiljahoz!"
            );
        }

        System.out.println("Befektetesi dontes rogzitve!");

        current_client++;

        if (current_client < clients.length) {
            showCurrentClient();
        } else {
            game_finished = true;

            System.out.println();
            System.out.println("=== JATEK VEGE ===");
            System.out.println("Minden ugyfel kiszolgalva!");
            System.out.println(
                    "Helyes dontesek: "
                            + correct_decisions
                            + "/" + clients.length
            );
        }
    }

    public Client getCurrentClient() {

        if (game_finished) {
            return null;
        }

        return clients[current_client];
    }

    public boolean isGameFinished() {
        return game_finished;
    }

    public int getCurrentClientNumber() {
        return Math.min(current_client + 1, clients.length);
    }

    public int getClientCount() {
        return clients.length;
    }

    public String getLastInvestment() {
        return last_investment;
    }

    public String getLastResult() {
        return last_result;
    }

    public int getCorrectDecisions() {
        return correct_decisions;
    }
}