
package tradedesk;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;

import java.util.Locale;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL33.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public class Window {

    private long window;

    private final int width = 1280;
    private final int height = 720;

    private Shader shader;
    private Texture desk;
    private Texture monitor;
    private TextRenderer text_renderer;

    private GameObject monitor_object;
    private Game game;

    private int vao;
    private int vbo;

    private int panel_shader;
    private int panel_vao;
    private int panel_vbo;

    public void init() {

        GLFWErrorCallback.createPrint(System.err).set();

        if (!glfwInit()) {
            throw new IllegalStateException(
                    "Nem sikerult elinditani a GLFW-et!"
            );
        }

        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        window = glfwCreateWindow(
                width,
                height,
                "TradeDesk 2D",
                NULL,
                NULL
        );

        if (window == NULL) {
            throw new RuntimeException(
                    "Nem sikerult letrehozni a jatekablakot!"
            );
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);

        GL.createCapabilities();

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        shader = new Shader();

        desk = new Texture("desk.png");
        monitor = new Texture("monitor.png");

        monitor_object = new GameObject(
                "Monitor",
                0.0f,
                0.12f,
                0.55f,
                0.48f
        );

        float[] vertices = {
                -1.0f, -1.0f, 0.0f, 0.0f,
                1.0f, -1.0f, 1.0f, 0.0f,
                1.0f,  1.0f, 1.0f, 1.0f,

                -1.0f, -1.0f, 0.0f, 0.0f,
                1.0f,  1.0f, 1.0f, 0.0f,
                -1.0f,  1.0f, 0.0f, 1.0f
        };

        vao = glGenVertexArrays();
        vbo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);

        glBufferData(
                GL_ARRAY_BUFFER,
                vertices,
                GL_DYNAMIC_DRAW
        );

        glVertexAttribPointer(
                0,
                2,
                GL_FLOAT,
                false,
                4 * Float.BYTES,
                0
        );

        glEnableVertexAttribArray(0);

        glVertexAttribPointer(
                1,
                2,
                GL_FLOAT,
                false,
                4 * Float.BYTES,
                2 * Float.BYTES
        );

        glEnableVertexAttribArray(1);

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);

        glUseProgram(shader.getProgramId());

        glUniform1i(
                glGetUniformLocation(
                        shader.getProgramId(),
                        "image"
                ),
                0
        );

        glUseProgram(0);

        initPanelRenderer();

        text_renderer = new TextRenderer();
    }

    private void initPanelRenderer() {

        String vertex_code = """
                #version 330 core
                layout (location = 0) in vec2 position;
                void main() {
                    gl_Position = vec4(position, 0.0, 1.0);
                }
                """;

        String fragment_code = """
                #version 330 core
                out vec4 color;
                uniform vec4 panel_color;
                void main() {
                    color = panel_color;
                }
                """;

        int vertex_shader = compileShader(
                GL_VERTEX_SHADER,
                vertex_code
        );

        int fragment_shader = compileShader(
                GL_FRAGMENT_SHADER,
                fragment_code
        );

        panel_shader = glCreateProgram();

        glAttachShader(panel_shader, vertex_shader);
        glAttachShader(panel_shader, fragment_shader);
        glLinkProgram(panel_shader);

        if (glGetProgrami(panel_shader, GL_LINK_STATUS) == GL_FALSE) {
            throw new RuntimeException(
                    glGetProgramInfoLog(panel_shader)
            );
        }

        glDeleteShader(vertex_shader);
        glDeleteShader(fragment_shader);

        panel_vao = glGenVertexArrays();
        panel_vbo = glGenBuffers();

        glBindVertexArray(panel_vao);
        glBindBuffer(GL_ARRAY_BUFFER, panel_vbo);

        glBufferData(
                GL_ARRAY_BUFFER,
                12L * Float.BYTES,
                GL_DYNAMIC_DRAW
        );

        glVertexAttribPointer(
                0,
                2,
                GL_FLOAT,
                false,
                2 * Float.BYTES,
                0
        );

        glEnableVertexAttribArray(0);

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }

    private int compileShader(int type, String code) {

        int shader_id = glCreateShader(type);

        glShaderSource(shader_id, code);
        glCompileShader(shader_id);

        if (glGetShaderi(shader_id, GL_COMPILE_STATUS) == GL_FALSE) {
            throw new RuntimeException(
                    glGetShaderInfoLog(shader_id)
            );
        }

        return shader_id;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public void update() {
        glfwPollEvents();
    }

    public void render() {

        int[] framebuffer_width = new int[1];
        int[] framebuffer_height = new int[1];

        glfwGetFramebufferSize(
                window,
                framebuffer_width,
                framebuffer_height
        );

        int current_width = framebuffer_width[0];
        int current_height = framebuffer_height[0];

        if (current_width <= 0 || current_height <= 0) {
            return;
        }

        glViewport(
                0,
                0,
                current_width,
                current_height
        );

        glClearColor(
                0.05f,
                0.08f,
                0.16f,
                1.0f
        );

        glClear(GL_COLOR_BUFFER_BIT);

        glUseProgram(shader.getProgramId());
        glBindVertexArray(vao);

        drawTexture(
                desk,
                0.0f,
                -0.45f,
                0.85f,
                0.45f
        );

        drawTexture(
                monitor,
                0.0f,
                0.12f,
                0.55f,
                0.48f
        );

        glBindVertexArray(0);
        glUseProgram(0);

        drawMonitorInterface(
                current_width,
                current_height
        );

        glfwSwapBuffers(window);
    }

    private void drawMonitorInterface(
            int current_width,
            int current_height
    ) {

        float scale = Math.min(
                current_width / 1280.0f,
                current_height / 720.0f
        );

        float center_x = current_width / 2.0f;
        float center_y = current_height * 0.44f;

        float panel_width = 460.0f * scale;
        float panel_height = 225.0f * scale;

        float panel_x = center_x - panel_width / 2.0f;
        float panel_y = center_y - panel_height / 2.0f;

        drawPanel(
                panel_x,
                panel_y,
                panel_width,
                panel_height,
                current_width,
                current_height,
                0.03f,
                0.09f,
                0.16f,
                0.95f
        );

        float text_x = panel_x + 14.0f * scale;
        float text_y = panel_y + 8.0f * scale;

        drawText(
                "TRADEDESK 2D",
                text_x,
                text_y,
                0.65f * scale,
                current_width,
                current_height
        );

        if (game == null) {
            return;
        }

        if (game.isGameFinished()) {

            drawText(
                    "Játék vége!",
                    text_x,
                    text_y + 45.0f * scale,
                    0.8f * scale,
                    current_width,
                    current_height
            );

            drawText(
                    "Helyes döntések: "
                            + game.getCorrectDecisions()
                            + "/" + game.getClientCount(),
                    text_x,
                    text_y + 90.0f * scale,
                    0.6f * scale,
                    current_width,
                    current_height
            );

            drawText(
                    "Minden ügyfél kiszolgálva!",
                    text_x,
                    text_y + 130.0f * scale,
                    0.55f * scale,
                    current_width,
                    current_height
            );

            return;
        }

        Client client = game.getCurrentClient();

        if (client == null) {
            return;
        }

        drawText(
                "Ügyfél: "
                        + game.getCurrentClientNumber()
                        + "/" + game.getClientCount(),
                text_x,
                text_y + 30.0f * scale,
                0.52f * scale,
                current_width,
                current_height
        );

        drawText(
                "Név: " + formatName(client.getName()),
                text_x,
                text_y + 55.0f * scale,
                0.52f * scale,
                current_width,
                current_height
        );

        drawText(
                "Összeg: "
                        + formatMoney(client.getMoney())
                        + " Ft",
                text_x,
                text_y + 80.0f * scale,
                0.52f * scale,
                current_width,
                current_height
        );

        drawText(
                "Kockázat: "
                        + formatRisk(client.getRiskLevel()),
                text_x,
                text_y + 105.0f * scale,
                0.52f * scale,
                current_width,
                current_height
        );

        drawText(
                "Hozam: "
                        + String.format(
                        Locale.US,
                        "%.1f",
                        client.getExpectedReturn()
                )
                        + "%",
                text_x,
                text_y + 130.0f * scale,
                0.52f * scale,
                current_width,
                current_height
        );

        drawText(
                "Válassz befektetést:",
                text_x,
                text_y + 158.0f * scale,
                0.50f * scale,
                current_width,
                current_height
        );

        drawText(
                "1: Állampapír",
                text_x,
                text_y + 184.0f * scale,
                0.42f * scale,
                current_width,
                current_height
        );

        drawText(
                "2: Részvény",
                text_x + 130.0f * scale,
                text_y + 184.0f * scale,
                0.42f * scale,
                current_width,
                current_height
        );

        drawText(
                "3: Alap",
                text_x + 260.0f * scale,
                text_y + 184.0f * scale,
                0.42f * scale,
                current_width,
                current_height
        );
    }

    private void drawPanel(
            float x,
            float y,
            float panel_width,
            float panel_height,
            int current_width,
            int current_height,
            float red,
            float green,
            float blue,
            float alpha
    ) {

        float left = x / current_width * 2.0f - 1.0f;
        float right = (x + panel_width) / current_width * 2.0f - 1.0f;

        float top = 1.0f - y / current_height * 2.0f;
        float bottom = 1.0f
                - (y + panel_height) / current_height * 2.0f;

        float[] vertices = {
                left, top,
                right, top,
                right, bottom,

                left, top,
                right, bottom,
                left, bottom
        };

        glUseProgram(panel_shader);

        glUniform4f(
                glGetUniformLocation(panel_shader, "panel_color"),
                red,
                green,
                blue,
                alpha
        );

        glBindVertexArray(panel_vao);
        glBindBuffer(GL_ARRAY_BUFFER, panel_vbo);

        glBufferSubData(
                GL_ARRAY_BUFFER,
                0,
                vertices
        );

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
        glUseProgram(0);
    }

    private void drawText(
            String text,
            float x,
            float y,
            float scale,
            int current_width,
            int current_height
    ) {

        text_renderer.drawText(
                text,
                x,
                y,
                scale,
                current_width,
                current_height
        );
    }

    private String formatName(String name) {

        return name
                .replace("Kovacs", "Kovács")
                .replace("Peter", "Péter")
                .replace("Szabo", "Szabó")
                .replace("Laszlo", "László");
    }

    private String formatRisk(String risk) {
        return risk.replace("Kozepes", "Közepes");
    }

    private String formatMoney(int money) {

        return String.format(Locale.US, "%,d", money)
                .replace(',', ' ');
    }

    private void drawTexture(
            Texture texture,
            float x,
            float y,
            float object_width,
            float object_height
    ) {

        float[] vertices = {
                x - object_width, y - object_height, 0.0f, 0.0f,
                x + object_width, y - object_height, 1.0f, 0.0f,
                x + object_width, y + object_height, 1.0f, 1.0f,

                x - object_width, y - object_height, 0.0f, 0.0f,
                x + object_width, y + object_height, 1.0f, 1.0f,
                x - object_width, y + object_height, 0.0f, 1.0f
        };

        glBindBuffer(GL_ARRAY_BUFFER, vbo);

        glBufferSubData(
                GL_ARRAY_BUFFER,
                0,
                vertices
        );

        glBindBuffer(GL_ARRAY_BUFFER, 0);

        texture.bind();

        glDrawArrays(GL_TRIANGLES, 0, 6);
    }

    public void checkClick(
            double mouse_x,
            double mouse_y
    ) {

        int[] window_width = new int[1];
        int[] window_height = new int[1];

        glfwGetWindowSize(
                window,
                window_width,
                window_height
        );

        if (window_width[0] <= 0 || window_height[0] <= 0) {
            return;
        }

        float x = (float) (
                mouse_x / window_width[0] * 2.0 - 1.0
        );

        float y = (float) (
                1.0 - mouse_y / window_height[0] * 2.0
        );

        if (monitor_object.contains(x, y)) {
            System.out.println("Monitor kivalasztva!");
        }
    }

    public boolean shouldClose() {
        return glfwWindowShouldClose(window);
    }

    public long getHandle() {
        return window;
    }

    public void cleanup() {

        if (text_renderer != null) {
            text_renderer.cleanup();
        }

        if (panel_vbo != 0) {
            glDeleteBuffers(panel_vbo);
        }

        if (panel_vao != 0) {
            glDeleteVertexArrays(panel_vao);
        }

        if (panel_shader != 0) {
            glDeleteProgram(panel_shader);
        }

        if (vbo != 0) {
            glDeleteBuffers(vbo);
        }

        if (vao != 0) {
            glDeleteVertexArrays(vao);
        }

        if (desk != null) {
            desk.cleanup();
        }

        if (monitor != null) {
            monitor.cleanup();
        }

        if (shader != null) {
            shader.cleanup();
        }

        if (window != NULL) {
            glfwDestroyWindow(window);
        }

        glfwTerminate();
    }
}