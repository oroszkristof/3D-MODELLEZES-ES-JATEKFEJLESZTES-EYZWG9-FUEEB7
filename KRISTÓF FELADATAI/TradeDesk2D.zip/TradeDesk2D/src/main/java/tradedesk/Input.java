
package tradedesk;

import static org.lwjgl.glfw.GLFW.*;

public class Input {

    private final long window;
    private final Window game_window;
    private final Game game;

    private boolean previous_left_pressed = false;
    private boolean previous_right_pressed = false;

    private boolean previous_key_1 = false;
    private boolean previous_key_2 = false;
    private boolean previous_key_3 = false;

    private double scroll_y = 0;

    public Input(Window game_window, Game game) {
        this.game_window = game_window;
        this.window = game_window.getHandle();
        this.game = game;
    }

    public void init() {
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

        glfwSetScrollCallback(window, (window_handle, x_offset, y_offset) -> {
            scroll_y += y_offset;
        });
    }

    public void update() {

        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
            glfwSetWindowShouldClose(window, true);
        }

        boolean key_1 = glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS;
        boolean key_2 = glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS;
        boolean key_3 = glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS;

        if (key_1 && !previous_key_1) {
            game.chooseInvestment(1);
        }

        if (key_2 && !previous_key_2) {
            game.chooseInvestment(2);
        }

        if (key_3 && !previous_key_3) {
            game.chooseInvestment(3);
        }

        previous_key_1 = key_1;
        previous_key_2 = key_2;
        previous_key_3 = key_3;

        boolean left_pressed =
                glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;

        boolean right_pressed =
                glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS;

        if (left_pressed && !previous_left_pressed) {

            double[] mouse_x = new double[1];
            double[] mouse_y = new double[1];

            glfwGetCursorPos(window, mouse_x, mouse_y);

            System.out.println(
                    "Bal egerkattintas! X: " + mouse_x[0] + " Y: " + mouse_y[0]
            );

            game_window.checkClick(mouse_x[0], mouse_y[0]);
        }

        if (right_pressed && !previous_right_pressed) {

            double[] mouse_x = new double[1];
            double[] mouse_y = new double[1];

            glfwGetCursorPos(window, mouse_x, mouse_y);

            System.out.println(
                    "Jobb egerkattintas! X: " + mouse_x[0] + " Y: " + mouse_y[0]
            );
        }

        previous_left_pressed = left_pressed;
        previous_right_pressed = right_pressed;

        if (scroll_y != 0) {

            if (scroll_y > 0) {
                System.out.println("Egergorgo: felfele");
            } else {
                System.out.println("Egergorgo: lefele");
            }

            scroll_y = 0;
        }
    }
}