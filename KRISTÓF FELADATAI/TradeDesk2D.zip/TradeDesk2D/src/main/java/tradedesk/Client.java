
package tradedesk;

public class Client {

    private String name;
    private int money;
    private String investment_goal;

    private String risk_level;
    private double expected_return;
    private String investment_profile;

    public Client(String name, int money, String investment_goal) {
        this.name = name;
        this.money = money;
        this.investment_goal = investment_goal;

        this.risk_level = "Alacsony";
        this.expected_return = 5.0;
        this.investment_profile = "Ovatos";
    }

    public String getName() {
        return name;
    }

    public int getMoney() {
        return money;
    }

    public String getInvestmentGoal() {
        return investment_goal;
    }

    public String getRiskLevel() {
        return risk_level;
    }

    public double getExpectedReturn() {
        return expected_return;
    }

    public String getInvestmentProfile() {
        return investment_profile;
    }

    public void setRiskProfile(
            String risk_level,
            double expected_return,
            String investment_profile
    ) {
        this.risk_level = risk_level;
        this.expected_return = expected_return;
        this.investment_profile = investment_profile;
    }

    public void showInfo() {
        System.out.println("Ugyfel neve: " + name);
        System.out.println("Befektetheto osszeg: " + money + " Ft");
        System.out.println("Befektetesi cel: " + investment_goal);

        System.out.println("Kockazati szint: " + risk_level);
        System.out.println("Elvart eves hozam: " + expected_return + "%");
        System.out.println("Befektetesi profil: " + investment_profile);
    }
}