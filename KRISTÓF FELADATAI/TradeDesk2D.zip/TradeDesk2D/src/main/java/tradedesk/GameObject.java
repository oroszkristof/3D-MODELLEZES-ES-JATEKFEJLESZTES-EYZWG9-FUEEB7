package tradedesk;

public class GameObject {

    private String name;

    private float x;
    private float y;

    private float width;
    private float height;

    public GameObject(String name, float x, float y, float width, float height) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public boolean contains(float mouse_x, float mouse_y) {
        return mouse_x >= x - width
                && mouse_x <= x + width
                && mouse_y >= y - height
                && mouse_y <= y + height;
    }
}
