package tradedesk;

import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTFontinfo;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.lwjgl.opengl.GL33.*;
import static org.lwjgl.stb.STBTruetype.*;

public class TextRenderer {

    private static final float FONT_SIZE = 32.0f;

    private final Map<Integer, Glyph> glyphs = new HashMap<>();

    private int shader_program;
    private int vao;
    private int vbo;

    private static class Glyph {

        int texture;
        int width;
        int height;
        int x_offset;
        int y_offset;
        float advance;

        Glyph(
                int texture,
                int width,
                int height,
                int x_offset,
                int y_offset,
                float advance
        ) {
            this.texture = texture;
            this.width = width;
            this.height = height;
            this.x_offset = x_offset;
            this.y_offset = y_offset;
            this.advance = advance;
        }
    }

    public TextRenderer() {

        loadFont();

        String vertex_code = """
                #version 330 core

                layout (location = 0) in vec4 vertex;

                out vec2 texture_coords;

                void main() {
                    gl_Position = vec4(vertex.xy, 0.0, 1.0);
                    texture_coords = vertex.zw;
                }
                """;

        String fragment_code = """
                #version 330 core

                in vec2 texture_coords;

                out vec4 color;

                uniform sampler2D font_image;

                void main() {
                    float alpha = texture(font_image, texture_coords).r;
                    color = vec4(1.0, 1.0, 1.0, alpha);
                }
                """;

        int vertex_shader = compileShader(
                GL_VERTEX_SHADER,
                vertex_code
        );

        int fragment_shader = compileShader(
                GL_FRAGMENT_SHADER,
                fragment_code
        );

        shader_program = glCreateProgram();

        glAttachShader(shader_program, vertex_shader);
        glAttachShader(shader_program, fragment_shader);
        glLinkProgram(shader_program);

        if (glGetProgrami(shader_program, GL_LINK_STATUS) == GL_FALSE) {
            throw new RuntimeException(
                    glGetProgramInfoLog(shader_program)
            );
        }

        glDeleteShader(vertex_shader);
        glDeleteShader(fragment_shader);

        vao = glGenVertexArrays();
        vbo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);

        glBufferData(
                GL_ARRAY_BUFFER,
                6L * 4 * Float.BYTES,
                GL_DYNAMIC_DRAW
        );

        glVertexAttribPointer(
                0,
                4,
                GL_FLOAT,
                false,
                4 * Float.BYTES,
                0
        );

        glEnableVertexAttribArray(0);

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);

        glUseProgram(shader_program);

        glUniform1i(
                glGetUniformLocation(shader_program, "font_image"),
                0
        );

        glUseProgram(0);
    }

    private void loadFont() {

        Path font_path = Path.of(
                "src/main/resources/fonts/arial.ttf"
        );

        if (!Files.isRegularFile(font_path)) {
            throw new RuntimeException(
                    "Nem talalhato a betutipus: "
                            + font_path.toAbsolutePath()
            );
        }

        try {

            byte[] font_bytes = Files.readAllBytes(font_path);

            if (font_bytes.length == 0) {
                throw new RuntimeException(
                        "Az Arial fajl ures!"
                );
            }

            ByteBuffer font_data = BufferUtils.createByteBuffer(
                    font_bytes.length
            );

            font_data.put(font_bytes);
            font_data.flip();

            int font_offset = stbtt_GetFontOffsetForIndex(
                    font_data,
                    0
            );

            if (font_offset < 0) {
                throw new RuntimeException(
                        "A fajl nem ervenyes TrueType vagy OpenType betutipus!"
                );
            }

            STBTTFontinfo font_info = STBTTFontinfo.malloc();

            try {

                if (!stbtt_InitFont(
                        font_info,
                        font_data,
                        font_offset
                )) {
                    throw new RuntimeException(
                            "Az STB nem tudta inicializalni a betutipust!"
                    );
                }

                float font_scale = stbtt_ScaleForPixelHeight(
                        font_info,
                        FONT_SIZE
                );

                String alphabet =
                        "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
                                "abcdefghijklmnopqrstuvwxyz" +
                                "0123456789" +
                                " ÁÉÍÓÖŐÚÜŰáéíóöőúüű" +
                                ".,:;!?%-()/+";

                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

                for (int i = 0; i < alphabet.length(); i++) {

                    int codepoint = alphabet.codePointAt(i);

                    if (glyphs.containsKey(codepoint)) {
                        continue;
                    }

                    IntBuffer width_buffer =
                            BufferUtils.createIntBuffer(1);

                    IntBuffer height_buffer =
                            BufferUtils.createIntBuffer(1);

                    IntBuffer x_offset_buffer =
                            BufferUtils.createIntBuffer(1);

                    IntBuffer y_offset_buffer =
                            BufferUtils.createIntBuffer(1);

                    ByteBuffer bitmap = stbtt_GetCodepointBitmap(
                            font_info,
                            0.0f,
                            font_scale,
                            codepoint,
                            width_buffer,
                            height_buffer,
                            x_offset_buffer,
                            y_offset_buffer
                    );

                    int glyph_width = width_buffer.get(0);
                    int glyph_height = height_buffer.get(0);

                    int x_offset = x_offset_buffer.get(0);
                    int y_offset = y_offset_buffer.get(0);

                    IntBuffer advance_buffer =
                            BufferUtils.createIntBuffer(1);

                    IntBuffer bearing_buffer =
                            BufferUtils.createIntBuffer(1);

                    stbtt_GetCodepointHMetrics(
                            font_info,
                            codepoint,
                            advance_buffer,
                            bearing_buffer
                    );

                    float advance =
                            advance_buffer.get(0) * font_scale;

                    int texture = 0;

                    if (bitmap != null
                            && glyph_width > 0
                            && glyph_height > 0) {

                        texture = glGenTextures();

                        glBindTexture(
                                GL_TEXTURE_2D,
                                texture
                        );

                        glTexImage2D(
                                GL_TEXTURE_2D,
                                0,
                                GL_R8,
                                glyph_width,
                                glyph_height,
                                0,
                                GL_RED,
                                GL_UNSIGNED_BYTE,
                                bitmap
                        );

                        glTexParameteri(
                                GL_TEXTURE_2D,
                                GL_TEXTURE_MIN_FILTER,
                                GL_LINEAR
                        );

                        glTexParameteri(
                                GL_TEXTURE_2D,
                                GL_TEXTURE_MAG_FILTER,
                                GL_LINEAR
                        );

                        glTexParameteri(
                                GL_TEXTURE_2D,
                                GL_TEXTURE_WRAP_S,
                                GL_CLAMP_TO_EDGE
                        );

                        glTexParameteri(
                                GL_TEXTURE_2D,
                                GL_TEXTURE_WRAP_T,
                                GL_CLAMP_TO_EDGE
                        );

                        glBindTexture(GL_TEXTURE_2D, 0);
                    }

                    glyphs.put(
                            codepoint,
                            new Glyph(
                                    texture,
                                    glyph_width,
                                    glyph_height,
                                    x_offset,
                                    y_offset,
                                    advance
                            )
                    );

                    if (bitmap != null) {
                        stbtt_FreeBitmap(bitmap);
                    }
                }

            } finally {
                font_info.free();
            }

        } catch (Exception exception) {
            throw new RuntimeException(
                    "Hiba az Arial betutipus betoltesekor: "
                            + exception.getMessage(),
                    exception
            );
        }
    }

    private int compileShader(int type, String code) {

        int shader = glCreateShader(type);

        glShaderSource(shader, code);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
            throw new RuntimeException(
                    glGetShaderInfoLog(shader)
            );
        }

        return shader;
    }

    public void drawText(
            String text,
            float x,
            float y,
            float scale,
            int window_width,
            int window_height
    ) {

        if (window_width <= 0 || window_height <= 0) {
            return;
        }

        glUseProgram(shader_program);
        glActiveTexture(GL_TEXTURE0);
        glBindVertexArray(vao);

        float current_x = x;
        float baseline_y = y + FONT_SIZE * scale;

        for (int i = 0; i < text.length(); i++) {

            int codepoint = text.codePointAt(i);

            if (Character.isSupplementaryCodePoint(codepoint)) {
                i++;
            }

            Glyph glyph = glyphs.get(codepoint);

            if (glyph == null) {
                continue;
            }

            if (glyph.texture != 0) {

                float x0 =
                        current_x + glyph.x_offset * scale;

                float y0 =
                        baseline_y + glyph.y_offset * scale;

                float x1 =
                        x0 + glyph.width * scale;

                float y1 =
                        y0 + glyph.height * scale;

                float left =
                        x0 / window_width * 2.0f - 1.0f;

                float right =
                        x1 / window_width * 2.0f - 1.0f;

                float top =
                        1.0f - y0 / window_height * 2.0f;

                float bottom =
                        1.0f - y1 / window_height * 2.0f;

                float[] vertices = {
                        left, top, 0.0f, 0.0f,
                        right, top, 1.0f, 0.0f,
                        right, bottom, 1.0f, 1.0f,

                        left, top, 0.0f, 0.0f,
                        right, bottom, 1.0f, 1.0f,
                        left, bottom, 0.0f, 1.0f
                };

                FloatBuffer vertex_buffer =
                        BufferUtils.createFloatBuffer(vertices.length);

                vertex_buffer.put(vertices);
                vertex_buffer.flip();

                glBindTexture(
                        GL_TEXTURE_2D,
                        glyph.texture
                );

                glBindBuffer(
                        GL_ARRAY_BUFFER,
                        vbo
                );

                glBufferSubData(
                        GL_ARRAY_BUFFER,
                        0,
                        vertex_buffer
                );

                glDrawArrays(
                        GL_TRIANGLES,
                        0,
                        6
                );
            }

            current_x += glyph.advance * scale;
        }

        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
        glBindTexture(GL_TEXTURE_2D, 0);
        glUseProgram(0);
    }

    public void cleanup() {

        for (Glyph glyph : glyphs.values()) {

            if (glyph.texture != 0) {
                glDeleteTextures(glyph.texture);
            }
        }

        glyphs.clear();

        if (vbo != 0) {
            glDeleteBuffers(vbo);
        }

        if (vao != 0) {
            glDeleteVertexArrays(vao);
        }

        if (shader_program != 0) {
            glDeleteProgram(shader_program);
        }
    }
}