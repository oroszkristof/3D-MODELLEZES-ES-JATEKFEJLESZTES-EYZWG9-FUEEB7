#version 330 core

layout (location = 0) in vec2 aPos;      // A 2D-s alakzat csúcspontjai
layout (location = 1) in vec2 aTexCoord; // A textúra (UV) koordináták

out vec2 TexCoord; // Ezt küldjük tovább a fragment shadernek

uniform mat4 projection; // Ortografikus projekciós mátrix a Java kódból
uniform mat4 model;      // Az adott objektum (pl. dosszié) pozíciója az asztalon

void main()
{
    gl_Position = projection * model * vec4(aPos, 0.0, 1.0);
    TexCoord = aTexCoord;
}