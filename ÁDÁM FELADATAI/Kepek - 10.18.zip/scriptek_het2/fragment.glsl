#version 330 core
in vec2 TexCoord;
out vec4 FragColor;

uniform sampler2D spriteTexture;
uniform vec4 colorTint;  // Színezés (pl. zöld/piros a gyertyáknak)
uniform bool useTexture; // Kapcsoló: igaz a gomboknál, hamis a gyertyáknál

void main() {
    if (useTexture) {
        vec4 texColor = texture(spriteTexture, TexCoord);
        if(texColor.a < 0.1) discard; // Átlátszó pixelek eldobása
        FragColor = texColor * colorTint;
    } else {
        FragColor = colorTint; // Tömör szín kitöltés a textúra nélküli elemekhez
    }
}